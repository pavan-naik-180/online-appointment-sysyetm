-- AlterTable
ALTER TABLE "Doctor" ADD COLUMN     "awardYear" TEXT,
ADD COLUMN     "expericenceEnd" TEXT,
ADD COLUMN     "expericenceStart" TEXT,
ADD COLUMN     "experienceHospitalName" TEXT;
