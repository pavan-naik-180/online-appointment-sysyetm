export const AppointmentsFilterable = ['searchTerm', 'appointmentTime','status']
export const AppointmentsSearchable = ['appointmentTime','status', 'purpose']