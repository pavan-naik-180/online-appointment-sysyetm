// const url = process.env.NODE_ENV === "development" ?  "http://localhost:5051/api/v1" : 'https://fix-my-phone-backend.vercel.app/api/v1'

export const getBaseUrl = () =>{
    return  'http://localhost:5000/api/v1';
}