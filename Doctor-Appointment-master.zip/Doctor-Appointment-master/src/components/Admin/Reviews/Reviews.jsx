import React from 'react'
import AdminLayout from '../AdminLayout/AdminLayout'
import userImg from '../../../images/john.png';
import './Reviews.css';

const AdminReviews = () => {
    return (
        <>
            <AdminLayout >
               
            </AdminLayout>
        </>
    )
}
export default AdminReviews;