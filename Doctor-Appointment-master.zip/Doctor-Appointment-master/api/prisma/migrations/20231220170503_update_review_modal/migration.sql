-- AlterTable
ALTER TABLE "Reviews" ALTER COLUMN "response" DROP NOT NULL;
